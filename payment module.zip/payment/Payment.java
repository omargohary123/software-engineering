
package payment;


public class Payment implements PrintBehavior ,AuthorizeBehavior {
private double amount ;
AuthorizeBehavior x;
PrintBehavior y;
  public void printNon(){};
    public void printCashTrans(){};
 public boolean AuthorizeNon(){return false ; };
    public boolean AuthorizeCash(){return false;};
    public boolean AuthorizeCredit1(){return false;};
    public boolean AuthorizeCredit2(){return false;};




    
    
}
