/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payment;

/**
 *
 * @author Omar Gohary
 */
public class cash extends Payment {
    private double tenderd;
    public static void main(String[] args) {
       cash c=new cash();
       System.out.print(c.AuthorizeCash());
    }
}
