/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payment;

/**
 *
 * @author Omar Gohary
 */
public interface AuthorizeBehavior {
    public boolean AuthorizeNon();
    public boolean AuthorizeCash();
    public boolean AuthorizeCredit1();
    public boolean AuthorizeCredit2();
}
