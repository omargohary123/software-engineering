/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payment;

/**
 *
 * @author Omar Gohary
 */
public class credit extends  Payment {
    private String name;
    private String type;
    private java.util.Date exData ;
    public static void main(String[] args) {
       
    }
}
